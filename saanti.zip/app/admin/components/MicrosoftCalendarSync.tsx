'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useToast } from '@/components/Toast'
import { Check, Loader2, RefreshCw } from 'lucide-react'

const MSIcon = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 21 21">
    <rect x="1" y="1" width="9" height="9" fill="#f25022"/>
    <rect x="11" y="1" width="9" height="9" fill="#7fba00"/>
    <rect x="1" y="11" width="9" height="9" fill="#00a4ef"/>
    <rect x="11" y="11" width="9" height="9" fill="#ffb900"/>
  </svg>
)

export default function MicrosoftCalendarSync() {
  const toast = useToast()
  const [status,     setStatus]     = useState<'loading' | 'connected' | 'disconnected'>('loading')
  const [userId,     setUserId]     = useState<string | null>(null)
  const [syncing,    setSyncing]    = useState(false)
  const [connecting, setConnecting] = useState(false)

  const checkStatus = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) return
      setUserId(session.user.id)
      const res  = await fetch(`/api/microsoft-calendar?action=status&userId=${session.user.id}`)
      const data = await res.json()
      setStatus(data.connected ? 'connected' : 'disconnected')
    } catch { setStatus('disconnected') }
  }

  useEffect(() => {
    checkStatus()
    const params = new URLSearchParams(window.location.search)
    const mscal  = params.get('mscal')
    if (mscal === 'connected') {
      toast.success('Microsoft Calendar conectado')
      checkStatus()
      window.history.replaceState({}, '', window.location.pathname)
    } else if (mscal === 'error') {
      toast.error('Error al conectar Microsoft Calendar')
      window.history.replaceState({}, '', window.location.pathname)
    }
  }, [])

  const handleConnect = async () => {
    if (!userId) return
    setConnecting(true)
    try {
      const res  = await fetch(`/api/microsoft-calendar?action=auth-url&userId=${userId}`)
      const data = await res.json()
      if (data.url) window.location.href = data.url
    } catch { toast.error('Error iniciando conexión'); setConnecting(false) }
  }

  const handleDisconnect = async () => {
    if (!userId || !confirm('¿Desconectar Outlook Calendar?')) return
    await fetch(`/api/microsoft-calendar?action=disconnect&userId=${userId}`)
    setStatus('disconnected')
    toast.success('Outlook Calendar desconectado')
  }

  const handleSync = async () => {
    if (!userId) return
    setSyncing(true)
    try {
      const res  = await fetch('/api/microsoft-calendar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'sync-all', userId }),
      })
      const data = await res.json()
      if (data.ok) toast.success(`${data.synced} cita${data.synced !== 1 ? 's' : ''} sincronizadas`)
      else toast.error(data.error || 'Error al sincronizar')
    } catch (e: any) { toast.error('Error: ' + e.message) }
    finally { setSyncing(false) }
  }

  if (status === 'loading') return null

  if (status === 'disconnected') {
    return (
      <button
        onClick={handleConnect}
        disabled={connecting}
        className="flex items-center gap-2 px-3 py-2 rounded-xl border transition-all disabled:opacity-50
          border-slate-200 bg-white hover:bg-slate-50 text-slate-600 text-xs font-semibold
          dark:bg-[#21262d] dark:border-[#30363d] dark:text-slate-300 dark:hover:bg-[#30363d]"
      >
        {connecting ? <Loader2 size={14} className="animate-spin text-sky-500" /> : <MSIcon />}
        {connecting ? 'Conectando...' : 'Conectar Outlook'}
      </button>
    )
  }

  return (
    <div className="flex items-center gap-1.5">
      {/* Estado conectado */}
      <button
        onClick={handleDisconnect}
        title="Click para desconectar"
        className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all
          bg-sky-50 text-sky-700 border border-sky-200
          hover:bg-red-50 hover:text-red-600 hover:border-red-200
          dark:bg-sky-900/30 dark:text-sky-400 dark:border-sky-800
          dark:hover:bg-red-900/30 dark:hover:text-red-400 dark:hover:border-red-800"
      >
        <MSIcon /> Outlook
      </button>
      {/* Sync */}
      <button
        onClick={handleSync}
        disabled={syncing}
        title="Sincronizar con Outlook"
        className="p-2 rounded-xl border transition-all disabled:opacity-50
          border-slate-200 text-slate-400 hover:text-sky-600 hover:border-sky-300 hover:bg-sky-50
          dark:border-[#30363d] dark:text-slate-500 dark:hover:text-sky-400 dark:hover:border-sky-700 dark:hover:bg-sky-900/20"
      >
        {syncing ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
      </button>
    </div>
  )
}
