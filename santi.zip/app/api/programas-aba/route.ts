// app/api/programas-aba/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase-admin'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const childId = searchParams.get('child_id')
  const programaId = searchParams.get('id')

  try {
    if (programaId) {
      // Obtener programa con sus sets y sesiones
      const { data, error } = await supabaseAdmin
        .from('programas_aba')
        .select(`
          *,
          objetivos_cp(*),
          sesiones_datos_aba(*, objetivo_cp_id),
          cambios_fase_aba(*)
        `)
        .eq('id', programaId)
        .maybeSingle()
      if (error) throw error
      return NextResponse.json({ data })
    }

    if (childId) {
      const { data, error } = await supabaseAdmin
        .from('programas_aba')
        .select(`
          *,
          objetivos_cp(*),
          sesiones_datos_aba(id, fecha, porcentaje_exito, frecuencia_valor, duracion_segundos, fase)
        `)
        .eq('child_id', childId)
        .order('created_at', { ascending: false })
      if (error) throw error
      const res = NextResponse.json({ data })
      res.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate')
      return res
    }

    return NextResponse.json({ error: 'Se requiere child_id o id' }, { status: 400 })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { action } = body

    if (action === 'crear_programa') {
      const { programa, objetivos } = body
      // Default fase_actual to 'intervencion' — never let the DB silently put 'linea_base'
      const programaConFase = { fase_actual: 'intervencion', ...programa }
      const { data: prog, error } = await supabaseAdmin
        .from('programas_aba')
        .insert(programaConFase)
        .select()
        .single()
      if (error) throw error

      // Insertar objetivos CP si vienen
      if (objetivos && objetivos.length > 0) {
        const objConId = objetivos.map((o: any, i: number) => ({
          ...o, programa_id: (prog as any).id, numero_set: i + 1,
        }))
        await supabaseAdmin.from('objetivos_cp').insert(objConId)
      }
      return NextResponse.json({ data: prog })
    }

    if (action === 'registrar_sesion') {
      const { sesion } = body
      // Calcular porcentaje_exito si no viene explícito pero hay oportunidades/respuestas
      const sesionConPct = { ...sesion }
      if (sesionConPct.porcentaje_exito == null && sesionConPct.oportunidades_totales > 0) {
        sesionConPct.porcentaje_exito = Math.round(
          (Number(sesionConPct.respuestas_correctas) / Number(sesionConPct.oportunidades_totales)) * 100
        )
      }
      const { data, error } = await supabaseAdmin
        .from('sesiones_datos_aba')
        .insert(sesionConPct)
        .select()
        .single()
      if (error) throw error

      // Verificar si se alcanzó el criterio de dominio
      await verificarCriterioDominio((sesion as any).programa_id)

      return NextResponse.json({ data })
    }

    if (action === 'actualizar_programa') {
      const { programa_id, updates } = body
      const ALLOWED = ['titulo', 'objetivo_lp', 'fase_actual', 'criterio_dominio_pct', 'criterio_sesiones_consecutivas']
      const safeUpdates: any = {}
      for (const key of ALLOWED) {
        if (updates[key] !== undefined) safeUpdates[key] = updates[key]
      }
      if (!programa_id || Object.keys(safeUpdates).length === 0) {
        return NextResponse.json({ error: 'programa_id y al menos un campo requeridos' }, { status: 400 })
      }
      const { data, error } = await supabaseAdmin
        .from('programas_aba')
        .update(safeUpdates)
        .eq('id', programa_id)
        .select()
        .single()
      if (error) throw error
      return NextResponse.json({ data })
    }

    if (action === 'actualizar_objetivo') {
      const { objetivo_id, estado, descripcion, materiales, sd_estimulo, unidad_positiva, unidad_negativa, reforzadores, correction_errores, generalizacion } = body
      const updates: any = {}
      if (estado !== undefined) {
        const ESTADOS_VALIDOS = ['pendiente', 'en_progreso', 'dominado']
        if (!ESTADOS_VALIDOS.includes(estado)) {
          return NextResponse.json({ error: 'estado inválido' }, { status: 400 })
        }
        updates.estado = estado
        if (estado === 'dominado') updates.fecha_dominio = new Date().toISOString().split('T')[0]
      }
      if (descripcion !== undefined) updates.descripcion = descripcion
      if (materiales !== undefined) updates.materiales = materiales
      if (sd_estimulo !== undefined) updates.sd_estimulo = sd_estimulo
      if (unidad_positiva !== undefined) updates.unidad_positiva = unidad_positiva
      if (unidad_negativa !== undefined) updates.unidad_negativa = unidad_negativa
      if (reforzadores !== undefined) updates.reforzadores = reforzadores
      if (correction_errores !== undefined) updates.correction_errores = correction_errores
      if (generalizacion !== undefined) updates.generalizacion = generalizacion
      if (!objetivo_id || Object.keys(updates).length === 0) {
        return NextResponse.json({ error: 'objetivo_id y al menos un campo requeridos' }, { status: 400 })
      }
      const { data, error } = await supabaseAdmin
        .from('objetivos_cp')
        .update(updates)
        .eq('id', objetivo_id)
        .select()
        .single()
      if (error) throw error

      // FIX clínico: si cambió el estado del set, sincronizar el estado del programa.
      //   · TODOS los sets dominados → programa estado = 'dominado'
      //   · Algún set NO dominado → programa estado = 'intervencion' (si estaba 'dominado')
      // Esto refleja la regla del centro: un programa solo se considera logrado
      // cuando TODOS sus sets están completados.
      if (estado !== undefined && (data as any)?.programa_id) {
        try {
          const programa_id = (data as any).programa_id
          const { data: allSets } = await supabaseAdmin
            .from('objetivos_cp')
            .select('estado')
            .eq('programa_id', programa_id)
          const sets = (allSets || []) as any[]
          const totalSets = sets.length
          const setsDominados = sets.filter(s => s.estado === 'dominado').length

          if (totalSets > 0 && totalSets === setsDominados) {
            // Todos los sets dominados → marcar programa como dominado
            await supabaseAdmin
              .from('programas_aba')
              .update({ estado: 'dominado', fase_actual: 'dominado', fecha_dominio: new Date().toISOString().split('T')[0] })
              .eq('id', programa_id)
          } else {
            // Algún set NO dominado → asegurarse que el programa no esté como 'dominado'
            const { data: prog } = await supabaseAdmin
              .from('programas_aba')
              .select('estado')
              .eq('id', programa_id)
              .maybeSingle()
            if (prog && (prog as any).estado === 'dominado') {
              await supabaseAdmin
                .from('programas_aba')
                .update({ estado: 'intervencion', fase_actual: 'intervencion' })
                .eq('id', programa_id)
            }
          }
        } catch { /* no bloquear el update del set */ }
      }

      return NextResponse.json({ data })
    }

    if (action === 'agregar_set') {
      const { programa_id, descripcion, materiales, sd_estimulo, unidad_positiva, unidad_negativa, reforzadores, correction_errores, generalizacion } = body
      if (!programa_id || !descripcion?.trim()) {
        return NextResponse.json({ error: 'programa_id y descripcion requeridos' }, { status: 400 })
      }
      // Get max numero_set for this program
      const { data: existing } = await supabaseAdmin
        .from('objetivos_cp')
        .select('numero_set')
        .eq('programa_id', programa_id)
        .order('numero_set', { ascending: false })
        .limit(1)
      const nextNum = (existing && existing.length > 0 ? (existing[0] as any).numero_set : 0) + 1
      const setData: any = { programa_id, descripcion: descripcion.trim(), numero_set: nextNum, estado: 'pendiente' }
      if (materiales) setData.materiales = materiales
      if (sd_estimulo) setData.sd_estimulo = sd_estimulo
      if (unidad_positiva) setData.unidad_positiva = unidad_positiva
      if (unidad_negativa) setData.unidad_negativa = unidad_negativa
      if (reforzadores) setData.reforzadores = reforzadores
      if (correction_errores) setData.correction_errores = correction_errores
      if (generalizacion) setData.generalizacion = generalizacion
      const { data, error } = await supabaseAdmin
        .from('objetivos_cp')
        .insert(setData)
        .select()
        .single()
      if (error) throw error

      // FIX clínico: si el programa estaba marcado como 'dominado' y se agrega
      // un set nuevo, el programa ya no está completo — revertir a 'intervencion'.
      // El nuevo set arranca como 'pendiente', por lo que el programa global vuelve
      // a estar en curso hasta que el terapeuta marque el nuevo set como dominado.
      try {
        const { data: prog } = await supabaseAdmin
          .from('programas_aba')
          .select('estado, fase_actual')
          .eq('id', programa_id)
          .maybeSingle()
        if (prog && (prog as any).estado === 'dominado') {
          await supabaseAdmin
            .from('programas_aba')
            .update({ estado: 'intervencion', fase_actual: 'intervencion' })
            .eq('id', programa_id)
        }
      } catch { /* no bloquear el create del set */ }

      return NextResponse.json({ data })
    }

    if (action === 'editar_sesion') {
      const { sesion_id, updates } = body
      if (!sesion_id) return NextResponse.json({ error: 'sesion_id requerido' }, { status: 400 })
      const safeUpdates: any = {}
      if (updates.fecha !== undefined) safeUpdates.fecha = updates.fecha
      if (updates.fase !== undefined) safeUpdates.fase = updates.fase
      if (updates.oportunidades_totales !== undefined) safeUpdates.oportunidades_totales = Number(updates.oportunidades_totales)
      if (updates.respuestas_correctas !== undefined) safeUpdates.respuestas_correctas = Number(updates.respuestas_correctas)
      if (updates.notas !== undefined) safeUpdates.notas = updates.notas
      if (updates.set !== undefined) safeUpdates.set = updates.set
      // Recalculate percentage
      const ot = safeUpdates.oportunidades_totales
      const rc = safeUpdates.respuestas_correctas
      if (ot != null && rc != null && ot > 0) {
        safeUpdates.porcentaje_exito = Math.round((rc / ot) * 100)
        safeUpdates.respuestas_incorrectas = Math.max(0, ot - rc)
      }
      const { data, error } = await supabaseAdmin
        .from('sesiones_datos_aba')
        .update(safeUpdates)
        .eq('id', sesion_id)
        .select()
        .single()
      if (error) throw error
      return NextResponse.json({ data })
    }

    if (action === 'eliminar_sesion') {
      const { sesion_id } = body
      if (!sesion_id) return NextResponse.json({ error: 'sesion_id requerido' }, { status: 400 })
      const { error } = await supabaseAdmin
        .from('sesiones_datos_aba')
        .delete()
        .eq('id', sesion_id)
      if (error) throw error
      return NextResponse.json({ ok: true })
    }
    if (action === 'actualizar_sesion_fecha') {
      const { sesion_id, fecha } = body
      if (!sesion_id || !fecha) return NextResponse.json({ error: 'sesion_id y fecha requeridos' }, { status: 400 })
      const { error } = await supabaseAdmin
        .from('sesiones_datos_aba')
        .update({ fecha })
        .eq('id', sesion_id)
      if (error) throw error
      return NextResponse.json({ ok: true })
    }


    if (action === 'editar_programa') {
      const { programa_id, updates } = body
      if (!programa_id) return NextResponse.json({ error: 'programa_id requerido' }, { status: 400 })
      const { data, error } = await supabaseAdmin
        .from('programas_aba')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', programa_id)
        .select()
        .single()
      if (error) throw error
      return NextResponse.json({ data })
    }

    if (action === 'eliminar_programa') {
      const { programa_id } = body
      if (!programa_id) return NextResponse.json({ error: 'programa_id requerido' }, { status: 400 })
      // Delete dependent records first
      await supabaseAdmin.from('sesiones_datos_aba').delete().eq('programa_id', programa_id)
      await supabaseAdmin.from('objetivos_cp').delete().eq('programa_id', programa_id)
      await supabaseAdmin.from('cambios_fase_aba').delete().eq('programa_id', programa_id)
      const { error } = await supabaseAdmin.from('programas_aba').delete().eq('id', programa_id)
      if (error) throw error
      return NextResponse.json({ ok: true })
    }

    if (action === 'cambiar_fase') {
      const { programa_id, child_id, fase_nueva, motivo, fase_anterior } = body
      const [cambio] = await Promise.all([
        supabaseAdmin.from('cambios_fase_aba').insert({
          programa_id, child_id, fase_nueva, fase_anterior, motivo,
        }).select().single(),
        supabaseAdmin.from('programas_aba').update({
          fase_actual: fase_nueva,
          ...(fase_nueva === 'dominado' ? { estado: 'dominado', fecha_dominio: new Date().toISOString().split('T')[0] } : {}),
        }).eq('id', programa_id),
      ])

      // Si el programa pasa a dominado, marcar también todos sus sets (objetivos_cp)
      // Esto garantiza que el contador del Hub IA sea siempre correcto (nivel 1)
      if (fase_nueva === 'dominado') {
        await supabaseAdmin
          .from('objetivos_cp')
          .update({ estado: 'dominado' })
          .eq('programa_id', programa_id)
          .neq('estado', 'dominado') // evitar escrituras innecesarias
      }

      return NextResponse.json({ data: cambio.data })
    }

    return NextResponse.json({ error: 'Acción no reconocida' }, { status: 400 })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json()
    const { id, ...updates } = body
    const { data, error } = await supabaseAdmin
      .from('programas_aba')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single()
    if (error) throw error
    return NextResponse.json({ data })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

// Verificar si se cumplió el criterio de dominio automáticamente
async function verificarCriterioDominio(programaId: string) {
  try {
    const { data: prog } = await supabaseAdmin
      .from('programas_aba')
      .select('criterio_dominio_pct, criterio_sesiones_consecutivas, fase_actual, titulo, child_id')
      .eq('id', programaId)
      .maybeSingle()
    if (!prog || (prog as any).fase_actual === 'dominado') return

    const { data: sesionesRaw } = await supabaseAdmin
      .from('sesiones_datos_aba')
      .select('porcentaje_exito, oportunidades_totales, respuestas_correctas, set, fecha')
      .eq('programa_id', programaId)
      .order('fecha', { ascending: true })

    if (!sesionesRaw || sesionesRaw.length === 0) return

    // Filtrar por el set más reciente activo
    const setsConSesiones = Array.from(new Set((sesionesRaw as any[]).map(s => s.set ?? '__none__')))
    const setActivo = setsConSesiones[setsConSesiones.length - 1]
    const sesionesSetActivo = (sesionesRaw as any[]).filter(s => (s.set ?? '__none__') === setActivo)

    if (sesionesSetActivo.length < (prog as any).criterio_sesiones_consecutivas) return

    // Tomar las últimas N sesiones del set activo
    const ultimas = sesionesSetActivo.slice(-(prog as any).criterio_sesiones_consecutivas)

    // Normalizar porcentaje_exito
    const sesiones = ultimas.map(s => ({
      porcentaje_exito: s.porcentaje_exito != null
        ? s.porcentaje_exito
        : (s.oportunidades_totales > 0
            ? Math.round((Number(s.respuestas_correctas) / Number(s.oportunidades_totales)) * 100)
            : 0)
    }))

    const cumpleCriterio = sesiones.every(
      s => s.porcentaje_exito >= (prog as any).criterio_dominio_pct
    )

    if (cumpleCriterio) {
      // Crear alerta de dominio alcanzado (positiva, prioridad informativa)
      await supabaseAdmin.from('agente_alertas').insert({
        child_id: (prog as any).child_id,
        programa_id: programaId,
        tipo: `logro_criterio_${programaId}`,
        titulo: `🎯 Criterio dominado: "${(prog as any).titulo}"`,
        descripcion: `Se alcanzó el criterio de ${(prog as any).criterio_dominio_pct}% en ${(prog as any).criterio_sesiones_consecutivas} sesiones consecutivas${setActivo !== '__none__' ? ` (${setActivo})` : ''}. Considera pasar a mantenimiento.`,
        prioridad: 3,
        resuelta: false,
      })
    }
  } catch (e) { /* silencioso */ }
}
